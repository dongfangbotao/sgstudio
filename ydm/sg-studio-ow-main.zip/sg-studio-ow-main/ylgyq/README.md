# yanglegeyang
羊了个羊前端

请各位自行fork后部署 学生党用vercel免费版太跑流量了 付不起

可参考[SleepyAsh0191](https://github.com/SleepyAsh0191/sheep-n-sheep-backend)搭建的后端

Thanks:

- @Arcxingye

- @SleepyAsh0191

- 所有被羊了个羊虐过的玩家们
