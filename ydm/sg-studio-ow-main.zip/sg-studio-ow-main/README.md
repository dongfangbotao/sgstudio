# studionew
模板，随意使用，放心使用
![屏幕截图 2022-10-04 213316](https://user-images.githubusercontent.com/109752157/194002556-2fd51a42-1c7e-4869-a752-e1fd330f0b4f.png)
