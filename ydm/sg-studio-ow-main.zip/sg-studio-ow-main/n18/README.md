关于此文件，详见仓库https://github.com/arcxingye/rr
